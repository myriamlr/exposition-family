acknowledgements <-
function(){
	print("This function serves to keep a list of those who have contributed to ExPosition (and related packages) throughout development.")
	
	full.list <- 
	rbind(
		cbind("Michael Meyners",""),
		cbind("Michael Meyners",""),
		cbind("Michael Meyners",""),
		cbind("Michael Meyners",""),
		cbind("Michael Meyners",""),
		cbind("Michael Meyners",""),
		cbind("Michael Meyners","")		
	)
	
}
