PDQ <-
function(datain,decomp.approach='svd',k=0){
	return(basePDQ(datain,decomp.approach=decomp.approach,k=k))	
}
